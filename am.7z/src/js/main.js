// Bootstrap 4
//= scripts/index.js
//= scripts/util.js
//= scripts/alert.js
//= scripts/button.js
// scripts/collapse.js
//= scripts/dropdown.js
//= scripts/scrollspy.js
//= scripts/tab.js

// Custom
//= scripts/custom/jquery.smartmenus.js
//= scripts/custom/jquery.smartmenus.bootstrap-4.js
//= scripts/custom/swiper.js
//= scripts/custom/jquery.fancybox.js
//= scripts/custom/bootstrap-select.js
//= scripts/custom/morph.js
// scripts/custom/js-offcanvas.pkgd.js
//= scripts/custom/my.js
